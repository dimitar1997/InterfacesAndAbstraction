package CarShop;

public interface Sellable {
    Double getPrice();
}
